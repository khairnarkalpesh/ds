import React, { useState } from "react";
import { IconType } from "react-icons";
import { FaTrophy } from "react-icons/fa";
import { GiTrophyCup } from "react-icons/gi";
import { AiOutlineTrophy } from "react-icons/ai";
import "./CongratsMessage.css";

interface Props {
  icon?: IconType;
}

const CongratsMessage: React.FC<Props> = ({ icon = FaTrophy }) => {
  const [isAnimating, setIsAnimating] = useState(false);

  const handleAnimationEnd = () => {
    setIsAnimating(false);
  };

  return (
    <div className={`congrats-message ${isAnimating ? "animate" : ""}`}>
      <h2>Congratulations, you won!</h2>
      {React.createElement(icon)}
      <button onClick={() => setIsAnimating(true)} disabled={isAnimating}>
        Celebrate!
      </button>
      <div className="confetti" onAnimationEnd={handleAnimationEnd}></div>
    </div>
  );
};

export default CongratsMessage;
