package com.projectws.springws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringwsApplicationTests {

	@Test
	void contextLoads() {
	}

}
